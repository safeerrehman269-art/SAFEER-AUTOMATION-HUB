import React from 'react';
import { motion } from 'motion/react';
import { PRODUCTS } from '../constants';
import { ShoppingCart, Zap, Key } from 'lucide-react';
import { CartItem } from '../types';

interface ShopProps {
  onAddToCart: (item: CartItem) => void;
}

export default function Shop({ onAddToCart }: ShopProps) {
  const workflows = PRODUCTS.filter(p => p.category === 'workflow');
  const keys = PRODUCTS.filter(p => p.category === 'key');

  return (
    <div className="py-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-16">
          <h1 className="text-4xl font-bold text-neutral-900 mb-4">Marketplace</h1>
          <p className="text-neutral-600">Browse our collection of premium AI workflows and API keys.</p>
        </div>

        {/* Workflows Section */}
        <div className="mb-20">
          <div className="flex items-center space-x-3 mb-8">
            <div className="bg-indigo-100 p-2 rounded-lg">
              <Zap className="h-6 w-6 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-neutral-900">AI Workflows</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {workflows.map((product) => (
              <ProductCard key={product.id} product={product} onAdd={onAddToCart} />
            ))}
          </div>
        </div>

        {/* Keys Section */}
        <div>
          <div className="flex items-center space-x-3 mb-8">
            <div className="bg-indigo-100 p-2 rounded-lg">
              <Key className="h-6 w-6 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-neutral-900">AI API Keys</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {keys.map((product) => (
              <ProductCard key={product.id} product={product} onAdd={onAddToCart} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

interface ProductCardProps {
  product: any;
  onAdd: (item: CartItem) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAdd }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white/90 backdrop-blur-sm rounded-3xl overflow-hidden shadow-sm border border-neutral-100 flex flex-col"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        {product.type === 'free' && (
          <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
            Free
          </div>
        )}
        {product.type === 'paid' && (
          <div className="absolute top-4 right-4 bg-indigo-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
            Premium
          </div>
        )}
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <h3 className="text-xl font-bold text-neutral-900 mb-2">{product.name}</h3>
        <p className="text-neutral-600 text-sm mb-6 flex-grow leading-relaxed">
          {product.description}
        </p>
        <div className="flex items-center justify-between mt-auto">
          <div className="text-2xl font-bold text-neutral-900">
            {product.price === 0 ? 'FREE' : `$${product.price}`}
          </div>
          <button 
            onClick={() => onAdd({ ...product, quantity: 1 })}
            className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all flex items-center space-x-2"
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}

