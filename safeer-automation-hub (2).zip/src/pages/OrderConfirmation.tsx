import { motion } from 'motion/react';
import { CheckCircle2, ArrowRight, MessageCircle, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SUPPORT_NUMBER } from '../constants';

export default function OrderConfirmation() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 py-20">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white/90 backdrop-blur-sm p-12 rounded-3xl shadow-xl border border-neutral-100 text-center max-w-2xl w-full"
      >
        <div className="bg-green-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
          <CheckCircle2 className="h-12 w-12 text-green-500" />
        </div>
        
        <h1 className="text-4xl font-extrabold text-neutral-900 mb-4 tracking-tight">
          Order Placed Successfully! ✅
        </h1>
        
        <p className="text-xl text-neutral-600 mb-10 leading-relaxed">
          Thank you for choosing Safeer Automation Hub. Your order details have been sent to our team via WhatsApp. 
          We will contact you shortly to provide your workflows and keys.
        </p>

        <div className="bg-neutral-50 rounded-2xl p-8 mb-10 text-left border border-neutral-100">
          <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center">
            <MessageCircle className="h-5 w-5 mr-2 text-indigo-600" />
            Next Steps
          </h3>
          <ul className="space-y-4 text-neutral-600">
            <li className="flex items-start">
              <span className="bg-indigo-100 text-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0 mt-0.5">1</span>
              <span>Our support team will verify your payment details on WhatsApp.</span>
            </li>
            <li className="flex items-start">
              <span className="bg-indigo-100 text-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0 mt-0.5">2</span>
              <span>Once verified, your automation files or API keys will be delivered directly to you.</span>
            </li>
            <li className="flex items-start">
              <span className="bg-indigo-100 text-indigo-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0 mt-0.5">3</span>
              <span>You'll receive a setup guide to help you get started immediately.</span>
            </li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
          <Link 
            to="/" 
            className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center"
          >
            <Home className="mr-2 h-5 w-5" />
            Back to Home
          </Link>
          <a 
            href={`https://wa.me/${SUPPORT_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white text-neutral-900 border-2 border-neutral-200 px-8 py-4 rounded-xl font-bold text-lg hover:bg-neutral-50 transition-all flex items-center justify-center"
          >
            <MessageCircle className="mr-2 h-5 w-5 text-green-500" />
            Chat with Support
          </a>
        </div>
      </motion.div>
    </div>
  );
}
