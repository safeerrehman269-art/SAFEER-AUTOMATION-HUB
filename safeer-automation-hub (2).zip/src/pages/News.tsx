import { motion } from 'motion/react';
import { NEWS } from '../constants';
import { Calendar, ArrowRight } from 'lucide-react';

export default function News() {
  return (
    <div className="py-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-neutral-900 mb-4">AI News & Updates</h1>
          <p className="text-neutral-600 max-w-2xl mx-auto">
            Stay ahead of the curve with the latest developments in artificial intelligence 
            and automation technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {NEWS.map((item, idx) => (
            <motion.article 
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white/80 backdrop-blur-sm rounded-3xl overflow-hidden shadow-sm border border-neutral-100 group"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-indigo-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  Free Access
                </div>
              </div>
              <div className="p-8">
                <div className="flex items-center text-neutral-400 text-sm mb-4">
                  <Calendar className="h-4 w-4 mr-2" />
                  {item.date}
                </div>
                <h2 className="text-2xl font-bold text-neutral-900 mb-4 group-hover:text-indigo-600 transition-colors">
                  {item.title}
                </h2>
                <p className="text-neutral-600 leading-relaxed mb-6">
                  {item.summary}
                </p>
                <button className="text-indigo-600 font-bold flex items-center hover:underline">
                  Read Full Article
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              </div>
            </motion.article>
          ))}
        </div>
        
        <div className="mt-20 bg-indigo-900/90 backdrop-blur-sm rounded-3xl p-12 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Want more insights?</h3>
          <p className="text-indigo-200 mb-8 max-w-xl mx-auto">
            Subscribe to our newsletter to get weekly AI automation tips and tricks 
            delivered straight to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row max-w-md mx-auto space-y-4 sm:space-y-0 sm:space-x-4">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-grow bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-bold hover:bg-neutral-100 transition-all">
              Subscribe
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
