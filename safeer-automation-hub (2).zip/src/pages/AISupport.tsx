import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { Send, MessageCircle, User, Cpu, Sparkles, Phone, Loader2 } from 'lucide-react';
import { SUPPORT_NUMBER } from '../constants';
import { GoogleGenAI } from '@google/genai';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export default function AISupport() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm Safeer Automation Hub's AI Support. I'm powered by advanced AI to help you with our workflows, keys, and any automation questions. How can I help you today?",
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    const userMessage: Message = {
      id: Date.now().toString(),
      text: userText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const systemPrompt = `You are the AI Support Assistant for "Safeer Automation Hub", a premium marketplace for AI automation workflows and API keys.
      Your goal is to help users understand our products and automation in general.
      
      Our Products:
      - Workflows: Instagram Auto Poster ($49), LinkedIn Lead Gen ($79), YouTube Script Writer ($39), Facebook Ad Generator ($59), Email Marketing Automator ($69), TikTok Trend Finder ($45), SEO Content Optimizer ($89), Twitter Thread Maker ($29).
      - API Keys: GPT 1.0 (Free), GPT 2.0 (Free), GPT 3.0 ($15), GPT 4.0 Pro ($30), GPT 5.0 Enterprise ($99).
      - Key Generator: Users can get 3-day trial for GPT 1, 4-day for GPT 2, and 2-day for GPT 3 on our "Key Gen" page.
      
      Support Info:
      - WhatsApp: ${SUPPORT_NUMBER}
      - Orders: Users must add to cart and then click "Order via WhatsApp".
      
      Guidelines:
      - Be professional, helpful, and friendly.
      - If you don't know something specific about an order, tell them to contact support on WhatsApp.
      - Keep answers concise but informative.
      - Use the user's language (English/Urdu/Roman Urdu) if they use it.`;

      // Filter out the initial AI message to ensure history starts with 'user'
      const history = messages
        .filter(m => m.id !== '1')
        .map(m => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }],
        }));

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...history,
          { role: 'user', parts: [{ text: userText }] }
        ],
        config: {
          systemInstruction: systemPrompt
        }
      });

      const aiText = response.text || "I'm sorry, I couldn't generate a response. Please try again.";

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiText,
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Gemini Error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm having a bit of trouble connecting right now. Please try again or contact our WhatsApp support for immediate help.",
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="py-16 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-neutral-900 mb-4">AI Support Agent</h1>
          <p className="text-neutral-600">Chat with our intelligent assistant for quick answers.</p>
        </div>

        <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl border border-neutral-100 overflow-hidden flex flex-col h-[600px]">
          {/* Chat Header */}
          <div className="bg-indigo-600 p-6 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-sm">
                <Cpu className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">Safeer AI Assistant</h3>
                <div className="flex items-center text-indigo-100 text-xs">
                  <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                  Online & Ready to Help
                </div>
              </div>
            </div>
            <a 
              href={`https://wa.me/${SUPPORT_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center"
            >
              <Phone className="h-4 w-4 mr-2" />
              WhatsApp
            </a>
          </div>

          {/* Chat Messages */}
          <div className="flex-grow overflow-y-auto p-6 space-y-6 bg-neutral-50/50">
            {messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex max-w-[80%] ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'} items-end space-x-2`}>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${msg.sender === 'user' ? 'bg-indigo-100 ml-2' : 'bg-indigo-600 mr-2'}`}>
                    {msg.sender === 'user' ? <User className="h-4 w-4 text-indigo-600" /> : <Sparkles className="h-4 w-4 text-white" />}
                  </div>
                  <div className={`p-4 rounded-2xl shadow-sm border ${
                    msg.sender === 'user' 
                    ? 'bg-indigo-600 text-white border-indigo-500 rounded-br-none' 
                    : 'bg-white text-neutral-800 border-neutral-100 rounded-bl-none'
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                    <div className={`text-[10px] mt-2 ${msg.sender === 'user' ? 'text-indigo-200' : 'text-neutral-400'}`}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
            {isLoading && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-start"
              >
                <div className="flex items-center space-x-2 bg-white p-4 rounded-2xl shadow-sm border border-neutral-100">
                  <Loader2 className="h-4 w-4 text-indigo-600 animate-spin" />
                  <span className="text-sm text-neutral-500">Safeer AI is thinking...</span>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <div className="p-6 bg-white border-t border-neutral-100">
            <form onSubmit={handleSend} className="flex space-x-4">
              <input
                type="text"
                value={input}
                disabled={isLoading}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isLoading ? "AI is responding..." : "Type your message here..."}
                className="flex-grow bg-neutral-50 border border-neutral-200 rounded-2xl px-6 py-4 text-neutral-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all outline-none disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="bg-indigo-600 text-white p-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center disabled:opacity-50 disabled:hover:bg-indigo-600"
              >
                {isLoading ? <Loader2 className="h-6 w-6 animate-spin" /> : <Send className="h-6 w-6" />}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
