import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Key, ShieldCheck, Clock, AlertCircle, Sparkles } from 'lucide-react';

export default function KeyGenerator() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<{ key: string; days: number; type: string } | null>(null);
  const [error, setError] = useState('');

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);

    const normalizedInput = input.toLowerCase().trim();

    if (normalizedInput.includes('gpt 1') || normalizedInput === '1') {
      setResult({ key: `FREE-GPT1-${Math.random().toString(36).substring(7).toUpperCase()}`, days: 3, type: 'ChatGPT 1.0' });
    } else if (normalizedInput.includes('gpt 2') || normalizedInput === '2') {
      setResult({ key: `FREE-GPT2-${Math.random().toString(36).substring(7).toUpperCase()}`, days: 4, type: 'ChatGPT 2.0' });
    } else if (normalizedInput.includes('gpt 3') || normalizedInput === '3') {
      setResult({ key: `FREE-GPT3-${Math.random().toString(36).substring(7).toUpperCase()}`, days: 2, type: 'ChatGPT 3.0' });
    } else if (normalizedInput.includes('gpt 4') || normalizedInput.includes('gpt 5')) {
      setError('ChatGPT 4 and 5 are PREMIUM keys. Please purchase them from the Shop to get your unique key.');
    } else {
      setError('Invalid key name. Please enter "GPT 1", "GPT 2", or "GPT 3" for free trials.');
    }
  };

  return (
    <div className="py-16 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-neutral-900 mb-4">Key Generator</h1>
          <p className="text-neutral-600">Enter the model name to generate your trial key.</p>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-neutral-100"
        >
          <form onSubmit={handleGenerate} className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-neutral-700 mb-2">Key Name (e.g., GPT 1, GPT 2, GPT 3)</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Key className="h-5 w-5 text-neutral-400" />
                </div>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter model name..."
                  className="block w-full pl-11 pr-4 py-4 bg-neutral-50 border border-neutral-200 rounded-2xl text-neutral-900 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center"
            >
              <Sparkles className="mr-2 h-5 w-5" />
              Generate Key
            </button>
          </form>

          {error && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-8 p-6 bg-red-50 border border-red-100 rounded-2xl flex items-start space-x-4"
            >
              <AlertCircle className="h-6 w-6 text-red-500 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-red-800 font-bold">Access Denied</h3>
                <p className="text-red-600 text-sm mt-1">{error}</p>
              </div>
            </motion.div>
          )}

          {result && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-8 p-8 bg-indigo-50 border border-indigo-100 rounded-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <ShieldCheck className="h-6 w-6 text-indigo-600" />
                  <h3 className="text-indigo-900 font-bold text-xl">Key Generated!</h3>
                </div>
                <div className="bg-indigo-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
                  {result.type}
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-xl border border-indigo-100 font-mono text-center text-lg font-bold text-indigo-600 mb-6 break-all">
                {result.key}
              </div>

              <div className="flex items-center justify-center space-x-2 text-indigo-700 font-medium">
                <Clock className="h-5 w-5" />
                <span>Valid for {result.days} days</span>
              </div>
            </motion.div>
          )}
        </motion.div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-neutral-100 text-center">
            <div className="text-indigo-600 font-bold text-2xl mb-1">3 Days</div>
            <div className="text-neutral-500 text-sm">GPT 1 Trial</div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-neutral-100 text-center">
            <div className="text-indigo-600 font-bold text-2xl mb-1">4 Days</div>
            <div className="text-neutral-500 text-sm">GPT 2 Trial</div>
          </div>
          <div className="bg-white p-6 rounded-2xl border border-neutral-100 text-center">
            <div className="text-indigo-600 font-bold text-2xl mb-1">2 Days</div>
            <div className="text-neutral-500 text-sm">GPT 3 Trial</div>
          </div>
        </div>
      </div>
    </div>
  );
}
