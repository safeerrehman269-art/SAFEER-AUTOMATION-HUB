import { motion } from 'motion/react';
import { Trash2, ShoppingBag, ArrowRight, MessageCircle, CreditCard } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { CartItem } from '../types';
import { SUPPORT_NUMBER } from '../constants';

interface CartProps {
  cart: CartItem[];
  onRemove: (id: string) => void;
  onClear: () => void;
}

export default function Cart({ cart, onRemove, onClear }: CartProps) {
  const navigate = useNavigate();
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handlePlaceOrder = () => {
    if (cart.length === 0) return;

    const orderDetails = cart.map(item => `${item.name} (x${item.quantity}) - $${item.price * item.quantity}`).join('%0A');
    const message = `Hello Safeer Automation Hub!%0AI would like to place an order:%0A%0A${orderDetails}%0A%0ATotal Amount: $${total}%0A%0APlease confirm my order.`;
    
    // Open WhatsApp
    window.open(`https://wa.me/${SUPPORT_NUMBER}?text=${message}`, '_blank');
    
    // Clear cart and redirect to confirmation
    onClear();
    navigate('/confirmation');
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-neutral-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-12 rounded-3xl shadow-sm border border-neutral-100 text-center max-w-md w-full">
          <div className="bg-indigo-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-8">
            <ShoppingBag className="h-10 w-10 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-neutral-900 mb-4">Your cart is empty</h2>
          <p className="text-neutral-600 mb-8 leading-relaxed">
            Looks like you haven't added any workflows yet. Explore our marketplace to get started.
          </p>
          <Link 
            to="/shop" 
            className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center group"
          >
            Go to Shop
            <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="py-16 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-neutral-900 mb-12">Your Shopping Cart</h1>
        
        <div className="lg:grid lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-8 space-y-6">
            {cart.map((item) => (
              <motion.div 
                key={item.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-neutral-100 flex items-center space-x-6"
              >
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-24 h-24 rounded-xl object-cover flex-shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-grow">
                  <h3 className="text-xl font-bold text-neutral-900 mb-1">{item.name}</h3>
                  <p className="text-neutral-500 text-sm mb-2">{item.category === 'workflow' ? 'AI Workflow' : 'API Key'}</p>
                  <div className="text-lg font-bold text-indigo-600">${item.price}</div>
                </div>
                <div className="flex flex-col items-end space-y-4">
                  <button 
                    onClick={() => onRemove(item.id)}
                    className="p-2 text-neutral-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="h-6 w-6" />
                  </button>
                  <div className="text-sm font-medium text-neutral-500">Qty: {item.quantity}</div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="lg:col-span-4 mt-12 lg:mt-0">
            <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-sm border border-neutral-100 sticky top-24">
              <h2 className="text-2xl font-bold text-neutral-900 mb-8">Order Summary</h2>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-neutral-600">
                  <span>Subtotal</span>
                  <span>${total}</span>
                </div>
                <div className="flex justify-between text-neutral-600">
                  <span>Tax</span>
                  <span>$0.00</span>
                </div>
                <div className="border-t border-neutral-100 pt-4 flex justify-between text-xl font-bold text-neutral-900">
                  <span>Total</span>
                  <span>${total}</span>
                </div>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={handlePlaceOrder}
                  className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center group"
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Order via WhatsApp
                </button>
                <p className="text-center text-xs text-neutral-400 leading-relaxed">
                  Clicking "Order via WhatsApp" will open a chat with our support team to finalize your purchase.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
