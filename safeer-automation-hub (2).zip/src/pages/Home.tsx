import { motion } from 'motion/react';
import { ArrowRight, Zap, Shield, Globe, MessageCircle, Cpu } from 'lucide-react';
import { Link } from 'react-router-dom';
import { SUPPORT_NUMBER } from '../constants';

export default function Home() {
  const features = [
    {
      icon: <Zap className="h-8 w-8 text-indigo-600" />,
      title: 'Lightning Fast',
      description: 'Automate repetitive tasks in seconds with our pre-built workflows.'
    },
    {
      icon: <Shield className="h-8 w-8 text-indigo-600" />,
      title: 'Secure & Reliable',
      description: 'Your data is safe with our enterprise-grade security protocols.'
    },
    {
      icon: <Globe className="h-8 w-8 text-indigo-600" />,
      title: 'Global Scale',
      description: 'Deploy automations that work across multiple platforms and regions.'
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-24 lg:pt-32 lg:pb-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="lg:grid lg:grid-cols-12 lg:gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-7"
            >
              <div className="inline-flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-8">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
                </span>
                <span>New: GPT-5 Workflows Now Available</span>
              </div>
              <h1 className="text-5xl lg:text-7xl font-extrabold text-neutral-900 tracking-tight leading-[1.1] mb-8 drop-shadow-sm">
                Automate Your <span className="text-indigo-600">Success</span> with Premium AI Workflows
              </h1>
              <p className="text-xl text-neutral-600 mb-10 max-w-2xl leading-relaxed drop-shadow-sm">
                Safeer Automation Hub is the world's leading marketplace for AI-powered 
                automation. From social media to enterprise lead generation, we've got you covered.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link 
                  to="/shop" 
                  className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center group"
                >
                  Explore Workflows
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Link>
                <a 
                  href={`https://wa.me/${SUPPORT_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-neutral-900 border-2 border-neutral-200 px-8 py-4 rounded-xl font-bold text-lg hover:bg-neutral-50 transition-all flex items-center justify-center"
                >
                  <MessageCircle className="mr-2 h-5 w-5 text-green-500" />
                  Contact Support
                </a>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="hidden lg:block lg:col-span-5"
            >
              <div className="relative">
                <div className="absolute -inset-4 bg-indigo-100 rounded-3xl blur-2xl opacity-50"></div>
                <img 
                  src="https://picsum.photos/seed/automation/800/800" 
                  alt="Automation Dashboard" 
                  className="relative rounded-3xl shadow-2xl border border-neutral-100"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Why Choose Safeer Automation?</h2>
            <p className="text-neutral-600 max-w-2xl mx-auto">
              We provide the most robust and easy-to-use AI workflows in the market.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {features.map((feature, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -5 }}
                className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-sm border border-neutral-100"
              >
                <div className="bg-indigo-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-neutral-900 mb-4">{feature.title}</h3>
                <p className="text-neutral-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-indigo-600/90 backdrop-blur-sm py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-8">
            Ready to scale your business with AI?
          </h2>
          <Link 
            to="/signup" 
            className="bg-white text-indigo-600 px-10 py-4 rounded-xl font-bold text-lg hover:bg-neutral-100 transition-all inline-flex items-center"
          >
            Create Your Account
            <Cpu className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
