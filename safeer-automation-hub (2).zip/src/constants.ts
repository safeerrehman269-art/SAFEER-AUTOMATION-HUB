import { Product, NewsItem } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'wf-1',
    name: 'Instagram Auto Poster',
    description: 'Automate your Instagram posts with AI-generated captions and scheduling.',
    price: 49,
    category: 'workflow',
    image: 'https://picsum.photos/seed/instagram/400/300'
  },
  {
    id: 'wf-2',
    name: 'LinkedIn Lead Gen',
    description: 'Extract leads and automate outreach on LinkedIn using AI personalization.',
    price: 79,
    category: 'workflow',
    image: 'https://picsum.photos/seed/linkedin/400/300'
  },
  {
    id: 'wf-3',
    name: 'YouTube Script Writer',
    description: 'Generate viral YouTube scripts and descriptions in seconds.',
    price: 39,
    category: 'workflow',
    image: 'https://picsum.photos/seed/youtube/400/300'
  },
  {
    id: 'wf-4',
    name: 'Facebook Ad Generator',
    description: 'Create high-converting Facebook ads with AI-driven copy and image suggestions.',
    price: 59,
    category: 'workflow',
    image: 'https://picsum.photos/seed/facebook/400/300'
  },
  {
    id: 'wf-5',
    name: 'Email Marketing Automator',
    description: 'Personalize and schedule email campaigns that actually get opened.',
    price: 69,
    category: 'workflow',
    image: 'https://picsum.photos/seed/email/400/300'
  },
  {
    id: 'wf-6',
    name: 'TikTok Trend Finder',
    description: 'Identify trending sounds and topics to boost your TikTok growth.',
    price: 45,
    category: 'workflow',
    image: 'https://picsum.photos/seed/tiktok/400/300'
  },
  {
    id: 'wf-7',
    name: 'SEO Content Optimizer',
    description: 'Analyze and optimize your blog posts for higher search engine rankings.',
    price: 89,
    category: 'workflow',
    image: 'https://picsum.photos/seed/seo/400/300'
  },
  {
    id: 'wf-8',
    name: 'Twitter Thread Maker',
    description: 'Turn long articles into engaging Twitter threads automatically.',
    price: 29,
    category: 'workflow',
    image: 'https://picsum.photos/seed/twitter/400/300'
  },
  {
    id: 'key-1',
    name: 'ChatGPT 1.0 API Key',
    description: 'Legacy access to GPT-1 for historical automation testing.',
    price: 0,
    category: 'key',
    type: 'free',
    image: 'https://picsum.photos/seed/gpt1/400/300'
  },
  {
    id: 'key-2',
    name: 'ChatGPT 2.0 API Key',
    description: 'Free access to GPT-2 for basic text generation tasks.',
    price: 0,
    category: 'key',
    type: 'free',
    image: 'https://picsum.photos/seed/gpt2/400/300'
  },
  {
    id: 'key-3',
    name: 'ChatGPT 3.0 API Key',
    description: 'Professional access to GPT-3 for high-quality content creation.',
    price: 15,
    category: 'key',
    type: 'paid',
    image: 'https://picsum.photos/seed/gpt3/400/300'
  },
  {
    id: 'key-4',
    name: 'ChatGPT 4.0 Pro Key',
    description: 'Premium access to GPT-4 for advanced reasoning and coding.',
    price: 30,
    category: 'key',
    type: 'paid',
    image: 'https://picsum.photos/seed/gpt4/400/300'
  },
  {
    id: 'key-5',
    name: 'ChatGPT 5.0 Enterprise',
    description: 'Next-gen AI capabilities for large scale enterprise automation.',
    price: 99,
    category: 'key',
    type: 'paid',
    image: 'https://picsum.photos/seed/gpt5/400/300'
  }
];

export const NEWS: NewsItem[] = [
  {
    id: 'n1',
    title: 'OpenAI Announces GPT-5',
    summary: 'The next generation of AI is here with unprecedented reasoning capabilities.',
    date: '2026-04-05',
    image: 'https://picsum.photos/seed/ai1/600/400'
  },
  {
    id: 'n2',
    title: 'Automation is the Future',
    summary: 'How businesses are saving 40% more time using AI workflows.',
    date: '2026-04-06',
    image: 'https://picsum.photos/seed/ai2/600/400'
  }
];

export const SUPPORT_NUMBER = '03293408114';
