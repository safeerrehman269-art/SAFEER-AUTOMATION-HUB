/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ChatWidget from './components/ChatWidget';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Shop from './pages/Shop';
import Cart from './pages/Cart';
import OrderConfirmation from './pages/OrderConfirmation';
import News from './pages/News';
import KeyGenerator from './pages/KeyGenerator';
import AISupport from './pages/AISupport';
import { User, CartItem } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) setUser(JSON.parse(savedUser));

    const savedCart = localStorage.getItem('cart');
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const addToCart = (item: CartItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      let newCart;
      if (existing) {
        newCart = prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      } else {
        newCart = [...prev, { ...item, quantity: 1 }];
      }
      localStorage.setItem('cart', JSON.stringify(newCart));
      return newCart;
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => {
      const newCart = prev.filter(i => i.id !== id);
      localStorage.setItem('cart', JSON.stringify(newCart));
      return newCart;
    });
  };

  const clearCart = () => {
    setCart([]);
    localStorage.removeItem('cart');
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col font-sans relative">
        {/* Global Background Video */}
        <div className="fixed inset-0 -z-10 overflow-hidden">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute min-w-full min-h-full object-cover opacity-40"
          >
            <source 
              src="https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-a-circuit-board-1664-large.mp4" 
              type="video/mp4" 
            />
          </video>
          {/* Readability Overlay */}
          <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px]"></div>
        </div>

        <Navbar user={user} onLogout={handleLogout} cartCount={cart.reduce((acc, i) => acc + i.quantity, 0)} />
        <main className="flex-grow relative z-10">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/news" element={<News />} />
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/signup" element={<Signup onSignup={handleLogin} />} />
            <Route path="/shop" element={user ? <Shop onAddToCart={addToCart} /> : <Navigate to="/login" />} />
            <Route path="/cart" element={user ? <Cart cart={cart} onRemove={removeFromCart} onClear={clearCart} /> : <Navigate to="/login" />} />
            <Route path="/confirmation" element={user ? <OrderConfirmation /> : <Navigate to="/login" />} />
            <Route path="/key-gen" element={user ? <KeyGenerator /> : <Navigate to="/login" />} />
            <Route path="/support" element={user ? <AISupport /> : <Navigate to="/login" />} />
          </Routes>
        </main>
        <ChatWidget />
        <Footer />
      </div>
    </Router>
  );
}

