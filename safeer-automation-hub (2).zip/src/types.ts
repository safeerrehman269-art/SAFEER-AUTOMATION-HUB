export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'workflow' | 'key';
  type?: 'free' | 'paid';
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  username: string;
  password?: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  date: string;
  image: string;
}
