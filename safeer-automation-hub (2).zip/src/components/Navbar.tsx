import { Link } from 'react-router-dom';
import { ShoppingCart, User as UserIcon, LogOut, Menu, X, Cpu } from 'lucide-react';
import { useState } from 'react';
import { User } from '../types';
import { cn } from '../lib/utils';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
  cartCount: number;
}

export default function Navbar({ user, onLogout, cartCount }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'AI News', path: '/news' },
    { name: 'Shop', path: '/shop' },
    { name: 'Key Gen', path: '/key-gen' },
    { name: 'AI Support', path: '/support' },
  ];

  return (
    <nav className="bg-white/70 backdrop-blur-lg border-b border-white/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-indigo-600 p-1.5 rounded-lg">
                <Cpu className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-neutral-900 tracking-tight drop-shadow-sm">
                Safeer <span className="text-indigo-600">Automation</span>
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-neutral-600 hover:text-indigo-600 font-medium transition-colors"
              >
                {link.name}
              </Link>
            ))}
            
            <div className="flex items-center space-x-4 border-l pl-4 border-neutral-200">
              <Link to="/cart" className="relative p-2 text-neutral-600 hover:text-indigo-600 transition-colors">
                <ShoppingCart className="h-6 w-6" />
                {cartCount > 0 && (
                  <span className="absolute top-0 right-0 bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                    {cartCount}
                  </span>
                )}
              </Link>

              {user ? (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 text-neutral-700">
                    <UserIcon className="h-5 w-5" />
                    <span className="font-medium">{user.username}</span>
                  </div>
                  <button
                    onClick={onLogout}
                    className="p-2 text-neutral-600 hover:text-red-600 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="bg-indigo-600 text-white px-5 py-2 rounded-full font-medium hover:bg-indigo-700 transition-all shadow-sm"
                >
                  Get Started
                </Link>
              )}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-neutral-600 hover:text-indigo-600 p-2"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-neutral-100 px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-indigo-600 hover:bg-neutral-50 rounded-md"
            >
              {link.name}
            </Link>
          ))}
          <Link
            to="/cart"
            onClick={() => setIsOpen(false)}
            className="flex items-center px-3 py-2 text-base font-medium text-neutral-600 hover:text-indigo-600 hover:bg-neutral-50 rounded-md"
          >
            Cart ({cartCount})
          </Link>
          {user ? (
            <button
              onClick={() => {
                onLogout();
                setIsOpen(false);
              }}
              className="w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 rounded-md"
            >
              Logout
            </button>
          ) : (
            <Link
              to="/login"
              onClick={() => setIsOpen(false)}
              className="block px-3 py-2 text-base font-medium text-indigo-600 hover:bg-indigo-50 rounded-md"
            >
              Login
            </Link>
          )}
        </div>
      )}
    </nav>
  );
}
