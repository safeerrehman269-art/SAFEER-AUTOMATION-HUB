import { MessageCircle, Mail, Phone, Github, Twitter } from 'lucide-react';
import { SUPPORT_NUMBER } from '../constants';

export default function Footer() {
  return (
    <footer className="bg-neutral-900/80 backdrop-blur-md text-white pt-16 pb-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold mb-6">
              Safeer <span className="text-indigo-400">Automation Hub</span>
            </h3>
            <p className="text-neutral-400 max-w-md leading-relaxed">
              Empowering businesses with premium AI automation workflows. 
              Save time, reduce costs, and scale your operations with our 
              curated marketplace of intelligent solutions.
            </p>
            <div className="flex space-x-4 mt-8">
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-neutral-400 hover:text-white transition-colors">
                <Github className="h-6 w-6" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-neutral-400">
              <li><a href="/" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="/shop" className="hover:text-white transition-colors">Workflows</a></li>
              <li><a href="/news" className="hover:text-white transition-colors">AI News</a></li>
              <li><a href="/cart" className="hover:text-white transition-colors">My Cart</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Support</h4>
            <ul className="space-y-4 text-neutral-400">
              <li className="flex items-center space-x-3">
                <MessageCircle className="h-5 w-5 text-green-400" />
                <a 
                  href={`https://wa.me/${SUPPORT_NUMBER}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  WhatsApp Support
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-5 w-5" />
                <span>{SUPPORT_NUMBER}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="h-5 w-5" />
                <span>support@safeerauto.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-800 pt-8 text-center text-neutral-500 text-sm">
          <p>© {new Date().getFullYear()} Safeer Automation Hub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
